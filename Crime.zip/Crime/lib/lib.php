<?php
#error_reporting(0);
error_reporting(E_ALL);
session_start();

//DB class -----
class DBTool{
	var $dbhost="localhost";
	var $dbport=3306;
	var $dbuser="root";
	var $dbpwd="akakame";
	var $dbname="crime";

	function connect()
	{

		$conn=new mysqli($this->dbhost,  $this->dbuser, $this->dbpwd, $this->dbname);


		if ($conn->connect_error) {
		    die("connection failed: " . $conn->connect_error);
		}

		return $conn;
	}

	function update($sql){

		$conn=$this->connect();
		$r=mysqli_query($conn,$sql);
		mysqli_close($conn);
		return $r;
	}

	function query($sql){

		$conn=$this->connect();
		//print_r($conn);
		$r=mysqli_query($conn,$sql);

		$arr=array();
		while($row = mysqli_fetch_array($r))
		  {
			  $arr[]=$row;
		  }
		mysqli_close($conn);
		return $arr;
	}


	function find($sql){

		$conn=$this->connect();
		$r=mysqli_query($conn,$sql);

		$obj=null;
		if($row = mysqli_fetch_array($r))
		  {
			  $obj=$row;

		  }
		mysqli_close($conn);
		return $obj;
	}



}


///Model class
class Model{

	var $tableData='';
	var $selectData='*';
	var $whereData='';
	var $orderData='';
	var $startpos=-1;
	var $count=0;
	var $DB;
	var $sql;

	function Model($t){
		$this->tableData=$t;
		$this->DB=new DBTool();
	}
	function  where($where){
		$this->whereData=$where;
		return $this;
		}
	function columes($select){
		$this->selectData=$select;
		return $this;

		}
	function  select(){
		return $this->query();
		}
	function find(){
		$row= $this->query();
		if($row && count($row)>0)
		return $row[0];
		else return '';
		}
	function order($order){
		$this->orderData=$order;
		return $this;
		}
	function limit($i,$j){
		$this->startpos=$i;
		$this->count=$j;
		return $this;
		}
	function query(){
			if($this->tableData==''){
				return '';
				}
			$sql="select ".$this->selectData." from ". $this->tableData." where 1=1 ";
			if($this->whereData!=''){
			$sql.=" and ".$this->whereData;
			}
			if($this->orderData!=''){
				$sql.=" order by ".$this->orderData;
				}
			if($this->startpos!=-1 && $this->count!=0){
				$sql.=" limit ".$this->startpos.",".$this->count." ";
				}
				$this->sql=$sql;
				return $this->DB->query($sql);


		}

	function lastSql(){
			return $this->sql;
		}

	function add($obj){
			$sql='insert into '.$this->tableData."(";
			$v="values (";
			foreach($obj as $key=>$val){
					$sql.=$key.",";
					$v1=str_replace("'","''",$val);
					$v.="'".$v1."',";
			}
			$v=substr($v,0,strlen($v)-1);
			$sql=substr($sql,0,strlen($sql)-1);
			$v.=")";
			$sql.=") ".$v;
			$this->sql=$sql;
			return $this->DB->update($sql);


		}

	function delete(){
		$sql="delete from ".$this->tableData." where 1=1 ";
		if($this->whereData!=''){
			$sql.=" and ".$this->whereData;
			}
			$this->sql=$sql;
			return $this->DB->update($sql);

	}

	function save($obj){
		$sql="update ".$this->tableData." set ";
		foreach($obj as $key=>$val){
					$v1=str_replace("'","''",$val);
					$sql.=$key."='".$v1."', ";

			}
		$sql=substr($sql,0,strlen($sql)-2);
		$sql.=" where 1=1 ";
		if($this->whereData!=''){
			$sql.=" and ".$this->whereData;
			}
			$this->sql=$sql;
			return $this->DB->update($sql);

	}

	}

// ----------------------------- function list
function D($url){
	header("location:$url");
}

function I($key){
	if(isset($_REQUEST[$key]))return $_REQUEST[$key];
	else return '';

}
function G($key){
	if(isset($_GET[$key]))return $_GET[$key];
	else return '';

}
function P($key){
	if(isset($_POST[$key]))return $_POST[$key];
	else return '';

}
function S($key){
	if(isset($_SESSION[$key]))return $_SESSION[$key];
	else return '';

}

function M($table)
{
	$m=new Model($table);
	return $m;

}

function F($key,$path="../upload/")
{
	if ($_FILES[$key]["error"] > 0)
	{
	    return 'err';
	}
	else
	{
	    $file=$_FILES[$key]["name"];
	    $ext=substr($file, strrpos($file, '.'));;

	    $name=time().mt_rand(1000,9999).$ext;
	    //echo $path.$name;
		move_uploaded_file($_FILES[$key]["tmp_name"], $path.$name);
		return "./upload/".$name;
	}

}





?>
