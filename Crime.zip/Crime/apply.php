<?php
require_once("./lib/lib.php");
$err='';
$ac=I('ac');
if($ac=='save'){
	
	$da['name']=I('name');
	$da['pwd']=I('pwd');
	$da['type']=I('type');
	
	
	$u=M('users')->where("name='".$da['name']."'")->find();
	if($u){
		$err='this name had been used by some one！';
		
		
	}
	else{
		M('users')->add($da);
		$err='apply over please to login';
		
	}
	
	
	
	
	
}
$types=M('usertype')->select();

?>
<!DOCTYPE html>
<?php require_once("common/head.php");?>
<html>
	
	<body>
		<?php require_once("./common/top.php");?>
		
		<div class="main">
			
			
			
			<div class="con">
				
				
				<form method="post" action="?ac=save">
					<div class="err"><?=$err?></div>
					<div class="ipt">
						<label>LoginName</label>
						<input name="name" />
					</div>
					<div class="ipt">
						<label>Password</label>
						<input name="pwd"  type="password"/>
					</div>
					<div class="ipt">
						<label>type</label>
						<select name="type">
							<?php foreach($types as $a) {?>
							<option value="<?=$a['id']?>"><?=$a['name']?></option>
							<?php }?>
						</select>
					</div>
					
					<div class="ipt">
						<label></label>
						<button>ToApply</button>
					</div>
				</form>
				
				
				
			</div>
			
		</div>
		
		<?php require_once("./common/footer.php");?>
		
	</body>
</html>
