<head>
		<meta charset="utf-8">
		<title>Crime Report System</title>
		<link href="style/style.css" type="text/css" rel="stylesheet" />
		<script src="./js/jquery.js"></script>
		<script>
			$(function(){
				$("img").error(function(){
					$(this).attr("src","./upload/banner.png");
				})
				
			})
		</script>
	</head>