<?php
$tps=M('newstype')->select();

?>
<div class="menu">
	<?php foreach($tps as $t)
	{
		$arr=M('news')->where("typeid=".$t['id'])->order(' id desc ')->limit(0,5)->select();
		?>
	<div class="tit"><?=$t['name']?></div>
	<ul>
		<?php foreach($arr as $a){  ?>
			<li><a href="newsdetail.php?id=<?=$a['id']?>"><?=$a['title']?></a>   </li>
		<?php }?>
	</ul>

	<?php }?>


</div>
