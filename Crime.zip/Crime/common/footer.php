<div class="friends">
			<span>Other Sites:</span>
			<a href="https://safety.gwu.edu/">GW Division of Safety and Security</a>
			<a href="http://crimemap.dc.gov/">DC Crime Map</a>
			<a href="https://mpdc.dc.gov/">DC Police Department</a>
			<a href="https://spotcrime.com/dc/washington/daily">DC spotcrime</a>




		</div>
		<div class="footer">
			Copy 2020 *********
		</div>
