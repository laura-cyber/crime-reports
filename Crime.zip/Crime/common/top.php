<?php


$u=S('user');

?>

<div class="logo">
			<span>Crime</span> Report System
		</div>

		<div class="nav">
			<div class="mm">
				<a href="index.php">Index</a>
				<a href="newslist.php?id=1">Notice</a>
				<a href="newslist.php?id=2">News</a>
				<a href="reportlist.php">Reports</a>
				<?php if($u && $u['type']==1){?>
					<a href="report.php?ac=edit">ReportCrime</a>
					<a href="report.php">MyReport</a>
					<a href="logout.php" class="r">Logout[<?=$u['name']?>]</a>
				<?php } else if($u && $u['type']==2){ ?>

					<a href="logout.php" class="r">Logout[<?=$u['name']?>]</a>

					<?php
				}
				?>
				<?php if(!$u){?>
					<a href="http://3.19.185.90/Crime/login.php">Login</a>
					<a href='http://3.19.185.90/Crime/admin/login.php'>Admin login</a >
				<?php }?>


			</div>
		</div>
