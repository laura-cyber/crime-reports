<?php
require_once("./lib/lib.php");

$id=I('id');
if($id=='')
$list=M('news')->select();
else
$list=M('news')->where("typeid=$id")->select();


?>
<!DOCTYPE html>
<?php require_once("common/head.php");?>
<html>

	<body>
		<?php require_once("common/top.php");?>

		<div class="main">

			<?php require_once("common/menunews.php");?>

			<div class="con">
				<div class="path">News List</div>

				<ul class="news">
					<?php foreach($list as $a){?>


					<li><a href="newsdetail.php?id=<?=$a['id']?>"><?=$a['title']?></a><span><?=$a['addtime']?></span></li>
					<?php }?>
				</ul>

			</div>

		</div>

		<?php require_once("./common/footer.php");?>

	</body>
</html>
