<?php

require_once("./lib/lib.php");
unset($_SESSION['user']);
D("./index.php");
?>