<!DOCTYPE html>
<?php require_once("./common/head.php");?>
<html>

	<body>
		<?php require_once("./common/top.php");?>

		<div class="main">

			<?php require_once("./common/menunews.php");?>

			<div class="con">
				<div class="path"> Report Log </div>
				<table>
					<thead>
						<tr>
							<td>ID</td>
							<td>Title</td>
							<td>Address</td>
							<td>Address Detail</td>
							<td>Status</td>
							<td>Option</td>
						</tr>
					</thead>
					<?php foreach($list as $t){?>
					<tr>
						<td><?=$t['id']?></td>
						<td><?=$t['title']?></td>
						<td><?=$t['address']?></td>
						<td><?=$t['addressDetail']?></td>
						<td><?=$t['status']?></td>
						<td><a href="?ac=del&id=<?=$t['id']?>"onclick="return confirm('makesure to delete?');">D</a>  <a href="?ac=edit&id=<?=$t['id']?>">E</a></td>
					</tr>
					<?php }?>

				</table>




			</div>

		</div>

		<?php require_once("./common/footer.php");?>

	</body>
</html>
