<!DOCTYPE html>
<?php require_once("./common/head.php");?>
<html>

	<body>
		<?php require_once("./common/top.php");?>

		<div class="main">

			<?php require_once("./common/menunews.php");?>

			<div class="con">
				<div class="path">Edit  Report</div>

				<form action="?ac=save" method="post" enctype="multipart/form-data">
					<input name="id" value="<?=$dat['id']?>" type="hidden" />
					<div class="ipt">
						<label>Title</label><input name="title" value="<?=$dat['title']?>" />
					</div>
					<div class="ipt">
						<label>Address</label><input name="address" value="<?=$dat['address']?>" />
					</div>
					<div class="ipt">
						<label>addressdetail</label><input name="addressDetail" value="<?=$dat['adressDetail']?>" />
					</div>
					<div class="ipt">
						<label>Description</label><textarea name="remark"><?=$dat['remark']?></textarea>
					</div>
					<div class="ipt">
						<label>Type</label>
						<select name="typeid">
							<?php foreach($types as $a) {?>
							<option value="<?=$a['id']?>"><?=$a['name']?></option>
							<?php }?>
						</select>
					</div>
					<div class="ipt">
						<label>Picture</label><input name="pic" type="file" />
					</div>


					<div class="ipt">
						<label></label><button type="submit">Save</button>
					</div>
				</form>




			</div>

		</div>

		<?php require_once("./common/footer.php");?>

	</body>
</html>
