<?php
require_once("lib/lib.php");
$u=S('user');
if(!$u){

	echo "<a href='./login.php'>please login first</a>";
	die;
}

$ac='list';
$tb='report';
$dao=M($tb);
if(G('ac'))$ac=G('ac');

if($ac=='list'){

	$list=$dao->where("userid=".$u['id'])->select();
	require_once("view/".$tb."list.php");
}
else if($ac=='del'){
	$id=I('id');
	$dao->where("id=$id")->delete();
	D($tb.".php");

}
else if($ac=='edit'){
	$id=I('id');
	$types=M('type')->select();
	$dat=[];
	if($id){
		$dat=$dao->where("id=$id")->find();
	}
	require_once("view/".$tb."edit.php");

}
else if($ac=='save'){
	$id=I('id');
	$d['title']=I('title');
	$d['address']=I('address');
	$d['addressDetail']=I('addressDetail');
	$d['remark']=I('remark');
	$d['typeid']=I('typeid');

	$d['pic']=F('pic');
	$d['userid']=$u['id'];


	if($id){
		$dao->where("id=$id")->save($d);
	}
	else{
		$d['addtime']=date("Y-m-d h:i:s",time());
		$dao->add($d);
	}
	D($tb.".php");



}

?>
