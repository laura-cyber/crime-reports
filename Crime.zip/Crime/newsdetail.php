<?php
require_once("./lib/lib.php");

$id=I('id');
if($id=='')$id=1;
$dat=M('news')->where("id=$id")->find();


?>
<!DOCTYPE html>
<?php require_once("common/head.php");?>
<html>

	<body>
		<?php require_once("common/top.php");?>

		<div class="main">

			<?php require_once("common/menunews.php");?>

			<div class="con">
				<div class="path">News Detail</div>

				<h2><?=$dat['title']?></h2>
				<p class="info">Author：<?=$dat['author']?>  &nbsp;&nbsp;&nbsp;&nbsp; Add Time: <?=$dat['addtime']?></p>
				<div class="detail">
					<img src="<?=$dat['pic']?>" width="80%"/>

					<?=$dat['content']?>

				</div>

			</div>

		</div>

		<?php require_once("./common/footer.php");?>

	</body>
</html>
