<?php
require_once("./lib/lib.php");

$id=I('id');
if($id=='')$id=1;

$u=S('user');
$status=P('status');
if($u && $u['type']==2 && $status){
	M('report')->where("id=$id")->save(array('status'=>$status));

}
$dat=M('report')->where("id=$id")->find();
?>
<!DOCTYPE html>
<?php require_once("common/head.php");?>
<html>

	<body>
		<?php require_once("common/top.php");?>

		<div class="main">

			<?php require_once("common/menureport.php");?>

			<div class="con">
				<div class="path">ReportDetail</div>

				<p class="p"><img src="<?=$dat['pic']?>"/></p>
				<h2><?=$dat['title']?></h2>
				<p><b>Address:</b><?=$dat['address']?></span>
				<p><b>AddressDetail:</b><span><?=$dat['addressDetail']?></span></p>
					<b>Status:</b><?=$dat['status']?></p>
				<p><b>Description:</b><?=$dat['remark']?></p>
				<?php
					$u=S('user');
					if($u && $u['type']==2){
				?>
				<form method="post">
					<div class="ipt">
						<label>Staff Option:</label>
						<select name="status">
							<option>NoAction</option><option>Processing</option><option>Completed</option>
						</select>
						<button >Change Status</button>
					</div>

				</form>
				<?php }?>

			</div>

		</div>

		<?php require_once("./common/footer.php");?>

	</body>
</html>
