<?php
require_once("./lib/lib.php");

$id=I('id');
if($id=='')
$list=M('report')->select();
else
$list=M('report')->where("typeid=$id")->select();


?>
<!DOCTYPE html>
<?php require_once("common/head.php");?>
<html>
	
	<body>
		<?php require_once("common/top.php");?>
		
		<div class="main">
			
			<?php require_once("common/menureport.php");?>
			
			<div class="con">
				<div class="path">ReportList</div>
				
				<ul class="news">
					<?php foreach($list as $a){?>
					
					
					<li><a href="reportdetail.php?id=<?=$a['id']?>"><?=$a['title']?></a><span><?=$a['addtime']?></span></li>
					<?php }?>
				</ul>
				
			</div>
			
		</div>
		
		<?php require_once("./common/footer.php");?>
		
	</body>
</html>
