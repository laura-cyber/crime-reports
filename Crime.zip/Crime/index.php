<?php

require_once("./lib/lib.php");

$news=M('news')->limit(0,8)->select();

$report=M('report')->where("typeid=1 or typeid=2")->limit(0,8)->select();
$report2=M('report')->where("typeid=3")->limit(0,8)->select();

$report3=M('report')->where("status='Completed'")->limit(0,8)->select();
?>
<!DOCTYPE html>
<?php require_once("./common/head.php");?>
<html>

	<body>
		<?php require_once("./common/top.php");?>

		<div class="main">



				<img src="upload/Crime.png"  width="100%" style="height: 300px;"/>


				<div class="bt">
					<div class="t">News & Notices</div>
					<div class="b"></div>
				</div>
				<ul class="inews">
					<?php
					foreach($news as $a){
						?>
						<li>
							<a href="newsdetail.php?id=<?=$a["id"]?>">
								<img src="<?=$a['pic']?>" />
								<?=$a['title']?>
								</a>
						</li>
						<?php }?>

				</ul>


				<div class="bt">
					<div class="t"> Lost and Found</div>
					<div class="b"></div>
				</div>
				<ul class="inews">
					<?php
					foreach($report as $a){
						?>
						<li>
							<a href="reportdetail.php?id=<?=$a["id"]?>">
								<img src="<?=$a['pic']?>" />
								<?=$a['title']?>
								</a>
						</li>
						<?php }?>

				</ul>


				<div class="bt">
					<div class="t">Crimes</div>
					<div class="b"></div>
				</div>
				<ul class="inews">
					<?php
					foreach($report2 as $a){
						?>
						<li>
								<a href="reportdetail.php?id=<?=$a["id"]?>">
								<img src="<?=$a['pic']?>" />
								<?=$a['title']?>
								</a>
						</li>
						<?php }?>

				</ul>

				<div class="bt">
					<div class="t">Completed Reports</div>
					<div class="b"></div>
				</div>
				<ul class="inews">
					<?php
					foreach($report3 as $a){
						?>
						<li>
							<a href="reportdetail.php?id=<?=$a['id']?>">
								<img src="<?=$a['pic']?>" />
								<?=$a['title']?>
								</a>
						</li>
						<?php }?>

				</ul>


		</div>

		<?php require_once("./common/footer.php");?>

	</body>
</html>
