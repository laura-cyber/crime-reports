<head>
		<meta charset="utf-8">
		<title>Crime Report System</title>
		<link href="../style/style.css" type="text/css" rel="stylesheet" />
	</head>