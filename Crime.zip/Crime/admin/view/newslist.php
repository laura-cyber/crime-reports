<!DOCTYPE html>
<?php require_once("head.php");?>
<html>

	<body>
		<?php require_once("top.php");?>

		<div class="main">

			<?php require_once("menu.php");?>

			<div class="con">
				<div class="path"> News Manager </div>
				<table>
					<thead>
						<tr>
							<td>ID</td>
							<td>Title</td>
							<td>Author</td>
							<td>Add Time</td>
							<td>Summary</td>
							<td>Option</td>
						</tr>
					</thead>
					<?php foreach($list as $t){?>
					<tr>
						<td><?=$t['id']?></td>
						<td><?=$t['title']?></td>
						<td><?=$t['author']?></td>
						<td><?=$t['addtime']?></td>
						<td><?=$t['summary']?></td>
						<td><a href="?ac=del&id=<?=$t['id']?>" onclick="return confirm('makesure to delete?');" >D</a>  <a href="?ac=edit&id=<?=$t['id']?>">E</a></td>
					</tr>
					<?php }?>

				</table>




			</div>

		</div>

		<?php require_once("../common/footer.php");?>

	</body>
</html>
