<!DOCTYPE html>
<?php require_once("head.php");?>
<html>

	<body>
		<?php require_once("top.php");?>

		<div class="main">

			<?php require_once("menu.php");?>

			<div class="con">
				<div class="path"> News Edit </div>

				<form action="?ac=save" method="post" enctype="multipart/form-data">
					<input name="id" value="<?=$dat['id']?>" type="hidden" />
					<div class="ipt">
						<label>Title</label><input name="title" value="<?=$dat['title']?>" />
					</div>
					<div class="ipt">
						<label>Author</label><input name="author" value="<?=$dat['author']?>" />
					</div>
					<div class="ipt">
						<label>Type</label>
						<select name="typeid">
							<?php foreach($types as $a) {?>
							<option value="<?=$a['id']?>"><?=$a['name']?></option>
							<?php }?>
						</select>
					</div>
					<div class="ipt">
						<label>Picture</label><input name="pic" type="file" />
					</div>
					<div class="ipt">
						<label>Summary</label><textarea name="summary"><?=$dat['summary']?></textarea>
					</div>
					<div class="ipt">
						<label></label><textarea name="content" id="content"><?=$dat['content']?></textarea>
					</div>
					<div class="ipt">
						<label></label><button type="submit">Save</button>
					</div>
				</form>




			</div>

		</div>

		<?php require_once("../common/footer.php");?>

	</body>
</html>
<script src="./kindeditor/kindeditor-all-min.js"></script>
<script>
	var editor = KindEditor.create('#content');
</script>
