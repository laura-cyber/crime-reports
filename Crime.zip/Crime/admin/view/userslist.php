<!DOCTYPE html>
<?php require_once("head.php");?>
<html>

	<body>
		<?php require_once("top.php");?>

		<div class="main">

			<?php require_once("menu.php");?>

			<div class="con">
				<div class="path"> UserManager </div>
				<table>
					<thead>
						<tr>
							<td>ID</td>
							<td>Username</td>
							<td>Password</td>
							<td>Type</td>
							<td>Option</td>
						</tr>
					</thead>
					<?php foreach($list as $t){?>
					<tr>
						<td><?=$t['id']?></td>
						<td><?=$t['name']?></td>
						<td><?=$t['pwd']?></td>
						<td><?=$t['type']?></td>

						<td><a href="?ac=del&id=<?=$t['id']?>"onclick="return confirm('makesure to delete?');">D</a>  <a href="?ac=edit&id=<?=$t['id']?>">E</a></td>
					</tr>
					<?php }?>

				</table>




			</div>

		</div>

		<?php require_once("../common/footer.php");?>

	</body>
</html>
