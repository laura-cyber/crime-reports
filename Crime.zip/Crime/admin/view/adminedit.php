<!DOCTYPE html>
<?php require_once("head.php");?>
<html>

	<body>
		<?php require_once("top.php");?>

		<div class="main">

			<?php require_once("menu.php");?>

			<div class="con">
				<div class="path"> Admin Edit </div>

				<form action="?ac=save" method="post" enctype="multipart/form-data">
					<input name="id" value="<?=$dat['id']?>" type="hidden" />
					<div class="ipt">
						<label>Username</label><input name="name" value="<?=$dat['name']?>" />
					</div>
					<div class="ipt">
						<label>Password</label><input name="pwd" value="<?=$dat['pwd']?>" />
					</div>
					<div class="ipt">
						<label>Realname</label>
						<input name="realname" value="<?=$dat['realname']?>" />
					</div>

					<div class="ipt">
						<label></label><button type="submit">Save</button>
					</div>
				</form>




			</div>

		</div>

		<?php require_once("../common/footer.php");?>

	</body>
</html>
