<?php
require_once("../lib/lib.php");
$ac='list';
#ac=action
$tb='report';
$dao=M($tb);
#M=创建一个数据库对象
if(G('ac'))$ac=G('ac');
#GET=G；POST=P

if($ac=='list'){

	$list=$dao->select();
	require_once("view/".$tb."list.php");
}
else if($ac=='del'){
	$id=I('id'); #I=request
	$dao->where("id=$id")->delete();
	D($tb.".php");

}
else if($ac=='edit'){
	$id=I('id');
	$types=M('type')->select(); 
	$dat=[];
	if($id){
		$dat=$dao->where("id=$id")->find();
	}
	require_once("view/".$tb."edit.php");

}
else if($ac=='save'){
	$id=I('id');
	$d['title']=I('title');
	$d['address']=I('address');
	$d['addressDetail']=I('addressDetail');
	$d['remark']=I('remark');
	$d['typeid']=I('typeid');
	$d['status']=I('status');
	$d['pic']=F('pic');
	$d['userid']=1;




	if($id){
		$dao->where("id=$id")->save($d);
	}
	else{
		$d['addtime']=date("Y-m-d h:i:s",time());
		$dao->add($d);
	}
	//echo $dao->lastSql();die;
	D($tb.".php");



}



?>
