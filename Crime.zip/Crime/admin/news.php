<?php

#error_reporting(E_ALL);
#ini_set("display_errors","On");

require_once("../lib/lib.php");
$ac='list';
$tb='news';
$dao=M($tb);
if(G('ac'))$ac=G('ac');


if($ac=='list'){

	$list=$dao->select();
	require_once("view/".$tb."list.php");
}
else if($ac=='del'){
	$id=I('id');
	$dao->where("id=$id")->delete();
	D($tb.".php");

}
else if($ac=='edit'){
	$id=I('id');
	$types=M('newstype')->select();
	$dat=[];
	if($id){
		$dat=$dao->where("id=$id")->find();
	}
	require_once("view/".$tb."edit.php");

}
else if($ac=='save'){
	$id=I('id');
	$d['title']=I('title');
	$d['author']=I('author');

	$d['summary']=I('summary');
	$d['typeid']=I('typeid');
	$d['content']=I('content');
	$d['pic']=F('pic');



	if($id){
		$dao->where("id=$id")->save($d);

	}
	else{
		$d['addtime']=date("Y-m-d h:i:s",time());
		$dao->add($d);
	}
	D($tb.".php");



}



?>
