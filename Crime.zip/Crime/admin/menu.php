<div class="menu">
				<div class="tit">NewsManagment</div>
				<ul>
					<li><a href="news.php">AllNews</a></li>
					<li><a href="news.php?ac=edit">AddNews</a></li>

				</ul>

				<div class="tit">ReportManagment</div>
				<ul>
					<li><a href="report.php">AllReport</a></li>
					<li><a href="report.php?ac=edit">AddReport</a></li>

				</ul>
				<div class="tit">UserManagment</div>
				<ul>
					<li><a href="users.php">AllUser</a></li>
					<li><a href="users.php?ac=edit">AddUser</a></li>
				</ul>
				<div class="tit">AdminManagment</div>
				<ul>
					<li><a href="admin.php">AllAdmin</a></li>
					<li><a href="admin.php?ac=edit">AddAdmin</a></li>
				</ul>
			</div>
