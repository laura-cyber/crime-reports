<?php

require_once("../lib/lib.php");
unset($_SESSION['admin']);
D("../index.php");
?>
