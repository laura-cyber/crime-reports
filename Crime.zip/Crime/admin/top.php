<div class="logo">
			<span>Crime</span> Report System
		</div>

		<div class="nav">
			<div class="mm">
			  <a href="./index.php">Index</a>
				<a href="./news.php">News</a>
				<a href="./report.php">Report</a>
				<a href="./users.php">Users</a>
				<a href="./admin.php">Admins</a>
				<a href="./logout.php">Logout</a>
			</div>
		</div>
