<?php
require_once("../lib/lib.php");
if(S('admin')==''){
	
	echo "<a href='./login.php'>please login first</a>";
	die;
}



?>