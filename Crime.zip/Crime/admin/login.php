<?php
require_once("../lib/lib.php");
$err='';
$name=P('name');
$pwd=P('pwd');
if($name){
	$r=M('admin')->where("name='$name' and pwd='$pwd'")->find();
	if($r){
		$_SESSION['admin']=$r;
		D('./index.php');
		die;
	}
	else{
		$err="please check you name and pwd";
	}
}

?>
<!DOCTYPE html>
<?php require_once("head.php");?>
<html>

	<body>
		<?php require_once("../common/top.php");?>

		<div class="main">



			<div class="con">

				<p></p><p></p><p></p><p></p>
				<form method="post">
					<div class="err"><?=$err?></div>
					<div class="ipt">
						<label>LoginName</label>
						<input name="name" />
					</div>
					<div class="ipt">
						<label>Password</label>
						<input name="pwd"  type="password"/>
					</div>

					<div class="ipt">
						<label></label>
						<button>ToLogin</button>
					</div>
				</form>



			</div>

		</div>

		<?php require_once("../common/footer.php");?>

	</body>
</html>
