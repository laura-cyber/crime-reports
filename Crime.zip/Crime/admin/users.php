<?php
require_once("../lib/lib.php");
$ac='list';
$tb='users';
$dao=M($tb);
if(G('ac'))$ac=G('ac');

if($ac=='list'){

	$list=$dao->select();
	require_once("view/".$tb."list.php");
}
else if($ac=='del'){
	$id=I('id');
	$dao->where("id=$id")->delete();
	D($tb.".php");

}
else if($ac=='edit'){
	$id=I('id');
	$types=M('usertype')->select();;
	$dat=[];
	if($id){
		$dat=$dao->where("id=$id")->find();
	}
	require_once("view/".$tb."edit.php");

}
else if($ac=='save'){
	$id=I('id');
	$d['name']=I('name');
	$d['pwd']=I('pwd');
	$d['type']=I('type');


	if($id){
		$dao->where("id=$id")->save($d);
	}
	else{
		$d['addtime']=date("Y-m-d h:i:s",time());
		$dao->add($d);
	}
	D($tb.".php");



}



?>
