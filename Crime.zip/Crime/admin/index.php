<?php
require_once("./common.php");



?>
<!DOCTYPE html>
<?php require_once("head.php");?>
<html>

	<body>
		<?php require_once("top.php");?>

		<div class="main">

			<?php require_once("menu.php");?>

			<div class="con">

				<h1>welcome to crime report management system</h1>



			</div>

		</div>

		<?php require_once("../common/footer.php");?>

	</body>
</html>
